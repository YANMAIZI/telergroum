# GTA5RP Order Management - Railway Deployment Guide

## 🚀 Быстрый старт на Railway

### Шаг 1: Подготовка проекта (✅ Уже сделано)

Все необходимые файлы созданы:
- ✅ `railway.json` - конфигурация Railway
- ✅ `Procfile` - запуск backend + bot
- ✅ `requirements.txt` - Python зависимости
- ✅ `runtime.txt` - версия Python
- ✅ `backend/server.js` - обновлен для Railway PORT

### Шаг 2: Создание Railway проекта

1. **Зарегистрироваться на Railway:**
   - Перейти на https://railway.app
   - Войти через GitHub

2. **Создать новый проект:**
   - Нажать "New Project"
   - Выбрать "Deploy from GitHub repo"
   - Выбрать ваш репозиторий `tgCHECK`

3. **Railway автоматически:**
   - Обнаружит Node.js (backend)
   - Обнаружит Python (bot)
   - Задеплоит оба сервиса

### Шаг 3: Настройка переменных окружения

В Railway Dashboard → Settings → Variables добавить:

```env
# Backend
PORT=3001
NODE_ENV=production

# Bot
BOT_TOKEN=8067623423:AAEVnx-MkUyEIOhnFoqCmZMVDwNo8lkPMtA
ADMIN_USER_ID=7858974852
API_BASE_URL=https://your-app-name.railway.app/api

# Для мини-приложения (если нужны уведомления)
REACT_APP_BOT_TOKEN=8067623423:AAEVnx-MkUyEIOhnFoqCmZMVDwNo8lkPMtA
REACT_APP_ADMIN_CHAT_ID=7858974852
```

> **Важно:** После деплоя замените `your-app-name.railway.app` на ваш реальный URL!

### Шаг 4: Получить URL сервиса

1. После деплоя Railway даст вам URL типа:
   ```
   https://your-app-name.railway.app
   ```

2. Обновите переменную `API_BASE_URL`:
   ```
   API_BASE_URL=https://your-app-name.railway.app/api
   ```

3. Redeploy проект (Settings → Redeploy)

### Шаг 5: Обновить мини-приложение

В файле `.env` вашего мини-приложения:

```env
REACT_APP_BACKEND_URL=https://your-app-name.railway.app/api
REACT_APP_BOT_TOKEN=8067623423:AAEVnx-MkUyEIOhnFoqCmZMVDwNo8lkPMtA
REACT_APP_ADMIN_CHAT_ID=7858974852
REACT_APP_ADMIN_USERNAME=patrickprodast
```

Затем перезапустите мини-приложение:
```bash
npm run dev
```

---

## ⚠️ Важные замечания

### Persistent Storage (Хранение данных)

Railway по умолчанию **не сохраняет файлы** между редеплоями!

**Проблема:** Файл `backend/data/orders.json` будет удаляться при каждом редеплое.

**Решения:**

#### Вариант 1: Railway Volumes (Рекомендуется)
```bash
# В Railway Dashboard:
1. Settings → Volumes
2. Add Volume: /app/backend/data
3. Redeploy
```

#### Вариант 2: Использовать MongoDB (Production-ready)
Railway предлагает бесплатный MongoDB addon:
1. В проекте нажать "New" → "Database" → "Add MongoDB"
2. Обновить `backend/server.js` для работы с MongoDB
3. Использовать connection string из Railway

---

## 🧪 Тестирование после деплоя

### 1. Проверить Backend
```bash
curl https://your-app-name.railway.app/api/health
```

Должно вернуть: `{"status":"ok","timestamp":"..."}`

### 2. Проверить Бота
- Откройте бота в Telegram
- Отправьте `/start`
- Бот должен ответить

### 3. Создать заявку через бот
- "Продать" → выберите сервер → укажите количество
- Проверьте что заявка сохранилась

### 4. Проверить мини-приложение
- Откройте мини-приложение
- "Купить вирты" → должна показываться статистика серверов
- Создайте заявку → она должна появиться в боте

---

## 📊 Мониторинг

Railway предоставляет:
- **Логи** - просмотр в реальном времени
- **Metrics** - CPU, Memory, Network
- **Deployments** - история деплоев

Доступ: Railway Dashboard → ваш проект → Logs/Metrics

---

## 🐛 Troubleshooting

### Backend не поднимается
**Проверьте логи:**
```
Railway Dashboard → Deployments → View Logs
```

**Частые проблемы:**
- Не установлены зависимости → проверьте `package.json`
- Неправильный PORT → используется `process.env.PORT`

### Бот не отвечает
**Проверьте:**
1. `BOT_TOKEN` правильный
2. `API_BASE_URL` указывает на Railway URL
3. Логи бота в Railway

### Мини-приложение не подключается
**Проверьте:**
1. CORS включен на backend (уже настроено)
2. `REACT_APP_BACKEND_URL` правильный
3. Backend доступен через HTTPS

---

## 💰 Стоимость Railway

**Free Tier (Бесплатно):**
- $5 кредитов в месяц
- Достаточно для малого трафика
- Автосон после 500MB RAM или $5

**Pro Plan ($20/месяц):**
- Unlimited usage
- Приоритетная поддержка
- Persistent volumes

---

## 📝 Альтернативы Railway

Если нужна другая платформа:
- **Render.com** - похож на Railway
- **Fly.io** - глобальный edge deployment
- **Vercel** - для frontend + serverless functions
- **Heroku** - классика (платный)

---

## ✅ Checklist деплоя

- [ ] Создан Railway проект
- [ ] Настроены переменные окружения
- [ ] Backend задеплоен и доступен по HTTPS
- [ ] Бот запущен и отвечает в Telegram
- [ ] Мини-приложение подключается к backend
- [ ] Создание заявок работает
- [ ] Настроен Persistent Storage (Volume или MongoDB)

**После выполнения всех пунктов - система готова к production! 🎉**
